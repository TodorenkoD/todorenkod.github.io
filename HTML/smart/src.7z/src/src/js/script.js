	//banner
	$(function() {
	    $('.bxslider').bxSlider({
	        auto: true,
	        adaptiveHeight: true,
	        controls: false
	    });
	});



function openOffcanvas() {
    document.getElementById("Sidenav").style.width = "250px";
}
function openNav() {
	document.getElementById("Sidenav").style.width = "250px";
    document.getElementById("myCanvasNav").style.width = "100%";
    document.getElementById("myCanvasNav").style.opacity = "0.8";  
}
function closeOffcanvas() {
    document.getElementById("Sidenav").style.width = "0%";
    document.getElementById("myCanvasNav").style.width = "0%";
    document.getElementById("myCanvasNav").style.opacity = "0"; 
}
function closeNav() {
	    document.getElementById("Sidenav").style.width = "0";
	    document.getElementById("myCanvasNav").style.width = "0%";

	}
    

	// //openNav
	// function openNav() {
	//     document.getElementById("Sidenav").style.width = "250px";
	// }

	// function closeNav() {
	//     document.getElementById("Sidenav").style.width = "0";
	// }



	//openSearch
	function openSearch() {
	    document.getElementById("Overlay").style.display = "block";
	}

	function closeSearch() {
	    document.getElementById("Overlay").style.display = "none";
	}
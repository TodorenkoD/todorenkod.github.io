	//banner
	$(function() {
	    $('.bxslider').bxSlider({
	        auto: true,
	        adaptiveHeight: true,
	        // controls: false
	    });
	});



	// lazy-scroll

	$(document).ready(function() {
	    $("#menu").on("click", "a", function(event) {
	        event.preventDefault();
	        var id = $(this).attr('href'),
	            top = $(id).offset().top;
	        $('body,html').animate({ scrollTop: top }, 1500);
	    });
	});


	//drop

	/* When the user clicks on the button, 
	toggle between hiding and showing the dropdown content */
	function myFunction() {
	    document.getElementById("myDropdown").classList.toggle("show");
	}

	// Close the dropdown menu if the user clicks outside of it
	window.onclick = function(event) {
	    if (!event.target.matches('.dropbtn')) {

	        var dropdowns = document.getElementsByClassName("dropdown-content");
	        var i;
	        for (i = 0; i < dropdowns.length; i++) {
	            var openDropdown = dropdowns[i];
	            if (openDropdown.classList.contains('show')) {
	                openDropdown.classList.remove('show');
	            }
	        }
	    }
	}

	//scrollup

	$(document).ready(function() {

	    $(window).scroll(function() {
	        if ($(this).scrollTop() > 100) {
	            $('.scrollup').fadeIn();
	        } else {
	            $('.scrollup').fadeOut();
	        }
	    });

	    $('.scrollup').click(function() {
	        $("html, body").animate({ scrollTop: 0 }, 600);
	        return false;
	    });

	});